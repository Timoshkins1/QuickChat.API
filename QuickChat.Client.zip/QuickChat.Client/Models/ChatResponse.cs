﻿namespace QuickChat.Client.Models
{
    public class ChatResponse
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
